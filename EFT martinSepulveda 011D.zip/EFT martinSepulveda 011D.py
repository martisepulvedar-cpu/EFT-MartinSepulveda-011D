#EFT MartinSepulveda 011D

planes = {
    'F001': ['Plan Básico', 'mensual', 1, False, False, 'libre'],
    'F002': ['Plan Full', 'mensual', 1, True, True, 'libre'],
    'F003': ['Plan Estudiante', 'trimestral', 3, False, True, 'tarde'],
    'F004': ['Plan Senior', 'trimestral', 3, True, False, 'mañana'],
    'F005': ['Plan Anual Pro', 'anual', 12, True, True, 'libre'],
    'F006': ['Plan Nocturno', 'mensual', 1, False, True, 'noche']
}

inscripciones = {
    'F001': [14990, 30],
    'F002': [22990, 10],
    'F003': [39990, 0],
    'F004': [35990, 6],
    'F005': [159990, 2],
    'F006': [18990, 15]
}


def leer_opcion():
    while True:
        try:
            opcion = int(input("Ingrese opción: "))
            return opcion
        except ValueError:
            print("Debe seleccionar una opción válida")


def buscar_codigo(codigo, dicc_planes):
    cod_mayuscula = codigo.upper()
    if cod_mayuscula in dicc_planes:
        return True
    else:
        return False

def cupos_tipo(tipo_plan, dicc_planes, dicc_inscripciones):
    tipo_buscado = tipo_plan.lower()
    total_cupos = 0
    
    for cod, datos in dicc_planes.items():
        tipo_actual = datos[1].lower() 
        if tipo_actual == tipo_buscado:
            datos_insc = dicc_inscripciones[cod]
            total_cupos = total_cupos + datos_insc[1]
            
    print(f"El total de cupos disponibles es: {total_cupos}")

def busqueda_precio(p_min, p_max, dicc_planes, dicc_inscripciones):
    planes_encontrados = []
    
    for cod, datos_insc in dicc_inscripciones.items():
        precio_actual = datos_insc[0] 
        if precio_actual >= p_min and precio_actual <= p_max:
            datos_plan = dicc_planes[cod]
            nombre_plan = datos_plan[0]
            formato_texto = f"{nombre_plan}--{cod}"
            planes_encontrados.append(formato_texto)
            
    if len(planes_encontrados) == 0:
        print("No hay planes en ese rango de precios.")
    else:
        planes_encontrados.sort()
        print(f"Los planes encontrados son: {planes_encontrados}")



def actualizar_precio(codigo, nuevo_precio, dicc_inscripciones):
    cod_mayuscula = codigo.upper()
    dicc_inscripciones[cod_mayuscula][0] = nuevo_precio
    return True

def agregar_plan(codigo, nombre, tipo, duracion, acceso_piscina, incluye_clases, horario, precio, cupos, dicc_planes, dicc_inscripciones):
    cod_mayuscula = codigo.upper()
    dicc_planes[cod_mayuscula] = [nombre, tipo, duracion, acceso_piscina, incluye_clases, horario]
    dicc_inscripciones[cod_mayuscula] = [precio, cupos]
    return True

def eliminar_plan(codigo, dicc_planes, dicc_inscripciones):
    cod_mayuscula = codigo.upper()
    
    if buscar_codigo(cod_mayuscula, dicc_planes):
        dicc_planes.pop(cod_mayuscula)
        dicc_inscripciones.pop(cod_mayuscula)
        return True
    else:
        return False

while True:
    print("\n========== MENÚ PRINCIPAL ==========")
    print("1. Cupos por tipo de plan")
    print("2. Búsqueda de planes por rango de precio")
    print("3. Actualizar precio de plan")
    print("4. Agregar plan")
    print("5. Eliminar plan")
    print("6. Salir")
    print("====================================")
    
    opc = leer_opcion()
    
    if opc == 1:
        tipo_ingresado = input("Ingrese tipo de plan a consultar: ")
        cupos_tipo(tipo_ingresado, planes, inscripciones)
        
    elif opc == 2:
        while True:
            try:
                p_min = int(input("Ingrese precio mínimo: "))
                p_max = int(input("Ingrese precio máximo: "))
                if p_min >= 0 and p_max >= 0:
                    break
                else:
                    print("Debe ingresar valores enteros positivos")
            except ValueError:
                print("Debe ingresar valores enteros")
                
        busqueda_precio(p_min, p_max, planes, inscripciones)
        
    elif opc == 3:
        while True:
            cod_buscar = input("Ingrese código del plan: ")
            if buscar_codigo(cod_buscar, planes):
                while True:
                    try:
                        n_precio = int(input("Ingrese nuevo precio: "))
                        if n_precio > 0:
                            break
                        else:
                            print("El precio debe ser un número entero mayor que cero")
                    except ValueError:
                        print("Debe ingresar un valor entero válido")
                if actualizar_precio(cod_buscar, n_precio, inscripciones):
                    print("Precio actualizado")
            else:
                print("El código no existe")
                
            resp = input("¿Desea actualizar otro precio (s/n)?: ").lower()
            if resp != 's':
                break
                
    elif opc == 4:
        print("--- Registrar Nuevo Plan ---")
        
        while True:
            cod_nuevo = input("Ingrese código del plan: ")
            if cod_nuevo.strip() == "":
                print("El código no puede estar vacío ni contener solo espacios")
            elif buscar_codigo(cod_nuevo, planes):
                print("El código ya existe en los diccionarios")
            else:
                break
                
        while True:
            nom_nuevo = input("Ingrese nombre del plan: ")
            if nom_nuevo.strip() == "":
                print("El nombre no puede estar vacío ni contener solo espacios")
            else:
                break
        while True:
            tipo_nuevo = input("Ingrese tipo (mensual/trimestral/anual): ").lower()
            if tipo_nuevo == 'mensual' or tipo_nuevo == 'trimestral' or tipo_nuevo == 'anual':
                break
            else:
                print("Debe ser exactamente 'mensual', 'trimestral' o 'anual'")
        while True:
            try:
                dur_nuevo = int(input("Ingrese duración (meses): "))
                if dur_nuevo > 0:
                    break
                else:
                    print("Número entero mayor que cero")
            except ValueError:
                print("Debe ingresar un número entero")
                
        while True:
            pisc_resp = input("¿Incluye acceso a piscina? (s/n): ").lower()
            if pisc_resp == 's':
                pisc_nuevo = True
                break
            elif pisc_resp == 'n':
                pisc_nuevo = False
                break
        while True:
            clases_resp = input("¿Incluye clases grupales? (s/n): ").lower()
            if clases_resp == 's':
                clases_nuevo = True
                break
            elif clases_resp == 'n':
                clases_nuevo = False
                break
        while True:
            hor_nuevo = input("Ingrese horario: ")
            if hor_nuevo.strip() == "":
                print("El horario no puede estar vacío ni contener solo espacios")
            else:
                break
        while True:
            try:
                prec_nuevo = int(input("Ingrese precio: "))
                if prec_nuevo > 0:
                    break
                else:
                    print("Número entero mayor que cero")
            except ValueError:
                print("Debe ingresar un número entero")
        while True:
            try:
                cupos_nuevo = int(input("Ingrese cupos: "))
                if cupos_nuevo >= 0:
                    break
                else:
                    print("Número entero mayor o igual a cero")
            except ValueError:
                print("Debe ingresar un número entero")
        agregar_plan(cod_nuevo, nom_nuevo, tipo_nuevo, dur_nuevo, pisc_nuevo, clases_nuevo, hor_nuevo, prec_nuevo, cupos_nuevo, planes, inscripciones)
        print("Plan agregado")
        
    elif opc == 5:
        cod_eliminar = input("Ingrese el código del plan a eliminar: ")
        if eliminar_plan(cod_eliminar, planes, inscripciones):
            print("Plan eliminado")
        else:
            print("El código no existe")
            
    elif opc == 6:
        print("Programa finalizado.")
        break
        
    else:
        print("Debe seleccionar una opción válida")